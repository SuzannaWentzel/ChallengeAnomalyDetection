package com.example.myapplication;

import android.Manifest;
import android.content.Context;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.location.Location;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

public class MainActivity extends AppCompatActivity implements SensorEventListener {

    private static final String TAG = "Example";

    Button button;

    private SensorManager sensorManager;
    Sensor accelerometer;

    //TextView xValue, yValue;
    TextView zValue;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        button = (Button) findViewById(R.id.button);

        sensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);

        accelerometer = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
        sensorManager.registerListener(MainActivity.this, accelerometer, SensorManager.SENSOR_DELAY_NORMAL);


        //xValue = (TextView) findViewById(R.id.xValue);
        //yValue = (TextView) findViewById(R.id.yValue);
        zValue = (TextView) findViewById(R.id.zValue);


        ActivityCompat.requestPermissions(MainActivity.this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION},123);

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                GPStracker g = new GPStracker(getApplicationContext());
                Location l = g.getLocation();
                if (l != null) {
                    Log.d(TAG, "het komt wel aan" );
                    double lat = l.getLatitude();
                    double lon = l.getLongitude();

                    Toast.makeText(getApplicationContext(), "lat: " + lat + "lon: " + lon, Toast.LENGTH_LONG).show();
                }
            }
        });
    }



    @Override
    public void onSensorChanged(SensorEvent sensorevent) {
        Sensor sensor = sensorevent.sensor;

        if (sensor.getType() == Sensor.TYPE_ACCELEROMETER) {
            Log.d(TAG, "Z: " + (sensorevent.values[2]-9.81));

            //xValue.setText("xValue: " + (sensorevent.values[0] - 9.81));
            //yValue.setText("yValue: " + (sensorevent.values[1] - 9.81));
            zValue.setText("zValue: " + (sensorevent.values[2] - 9.81));

        }

        if((sensorevent.values[2]-9.81) < 0){
            Log.d(TAG, "dit is een klein kut weggetje man");
            GPStracker g = new GPStracker(getApplicationContext());
            Location l = g.getLocation();

            if (l != null) {
                Log.d(TAG, "het komt wel aan" );
                double lat = l.getLatitude();
                double lon = l.getLongitude();
                Toast.makeText(getApplicationContext(), "lat: " + lat + "lon: " + lon, Toast.LENGTH_LONG).show();
            }
        }
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int i) {

    }
}

